/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package put.ai.games.game;

/**
 * Opis ruchu polegającego na położeniu piona
 */
public interface Move {

    /**
     * Kolor piona do położenia
     */
    public Player.Color getColor();
}
