/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package put.ai.games.alfabetaplayer;

import java.util.List;
import put.ai.games.game.Board;
import put.ai.games.game.Move;
import put.ai.games.game.Player;

public class AlfaBetaPlayer extends Player {

    private long startTime;
    private long maxTime;
    private int maxDepth = 20;

    @Override
    public String getName() {
        return "Jakub Klosinski 145959 Klaudiusz Szklarkowski 151801";
    }

    @Override
    public Move nextMove(Board b) {
        startTime = System.currentTimeMillis();
        maxTime = getTime();

        List<Move> moves = b.getMovesFor(getColor());
        Move bestMove = null;
        int bestValue = Integer.MIN_VALUE;

        for (Move move : moves) {
            b.doMove(move);
            int moveValue = alphaBeta(b, 0, Integer.MIN_VALUE, Integer.MAX_VALUE, false, moves.size());
            b.undoMove(move);

            if (moveValue > bestValue) {
                bestMove = move;
                bestValue = moveValue;
            }

            if (System.currentTimeMillis() - startTime + (moves.size()/4L) >= maxTime) {
                break;
            }
        }

        return bestMove;
    }

    private int alphaBeta(Board board, int depth, int alpha, int beta, boolean maximizingPlayer, int size) {
        if (depth == maxDepth || System.currentTimeMillis() - startTime + (size/4L) >= maxTime) {
            return evaluateBoard(board);
        }

        if (maximizingPlayer) {
            int maxEval = Integer.MIN_VALUE;
            for (Move move : board.getMovesFor(getColor())) {
                board.doMove(move);
                int eval = alphaBeta(board, depth + 1, alpha, beta, false, size);
                board.undoMove(move);
                maxEval = Math.max(maxEval, eval);
                alpha = Math.max(alpha, eval);
                if (beta <= alpha) {
                    break;
                }
            }
            return maxEval;
        } else {
            int minEval = Integer.MAX_VALUE;
            for (Move move : board.getMovesFor(getOpponent(getColor()))) {
                board.doMove(move);
                int eval = alphaBeta(board, depth + 1, alpha, beta, true, size);
                board.undoMove(move);
                minEval = Math.min(minEval, eval);
                beta = Math.min(beta, eval);
                if (beta <= alpha) {
                    break;
                }
            }
            return minEval;
        }
    }

    private int evaluateBoard(Board board) {
        int score = 0;
        Color myColor = getColor();
        Color opponentColor = getOpponent(myColor);
        int boardSize = board.getSize();

        for (int x = 0; x < boardSize; x++) {
            for (int y = 0; y < boardSize; y++) {
                score += evaluatePosition(board, x, y, myColor) - evaluatePosition(board, x, y, opponentColor);
            }
        }

        return score;
    }

    private int evaluatePosition(Board board, int x, int y, Color color) {
        int lineScore = 0;
        lineScore += checkLine(board, x, y, 1, 0, color); // Poziomo
        lineScore += checkLine(board, x, y, 0, 1, color); // Pionowo
        lineScore += checkLine(board, x, y, 1, 1, color); // Skośnie w prawo
        lineScore += checkLine(board, x, y, -1, 1, color); // Skośnie w lewo

        // Strategiczne pozycjonowanie
        if (isCentral(x, y, board.getSize())) {
            lineScore += 2; // Dodatkowe punkty za centralne pozycje
        }

        return lineScore;
    }

    private int checkLine(Board board, int x, int y, int dx, int dy, Color color) {
        int count = 0, empty = 0;
        for (int i = 0; i < 5; i++) {
            if (x < 0 || y < 0 || x >= board.getSize() || y >= board.getSize()) {
                break;
            }
            if (board.getState(x, y) == color) {
                count++;
            } else if (board.getState(x, y) == Color.EMPTY) {
                empty++;
            }
            x += dx;
            y += dy;
        }
        if (count + empty == 5) { // Tylko jeśli istnieje potencjał na pełną linię
            return count * count; // Zwiększona waga dla większej liczby pionków
        }
        return 0;
    }

    private boolean isCentral(int x, int y, int size) {
        int centralRegion = size / 4;
        return (x >= centralRegion && x < size - centralRegion) && (y >= centralRegion && y < size - centralRegion);
    }

}
